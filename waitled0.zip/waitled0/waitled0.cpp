#include <waitled0.h>
#include <Arduino.h>
 
void waitled0 :: waitms(){
    if(digitalRead(h)){
      j =millis();
    }

  if (((millis()-j)>=z)||digitalRead(x)){digitalWrite(y,0); }
  
  }

  void waitled0 :: waits(int b)
  {
    g=b;
  if(digitalRead(h)){
      j =millis();
    }
      if (((millis()-j)>=(1000*g))||digitalRead(x)){digitalWrite(y,0); }
  }
  
  waitled0 :: waitled0 (byte pb,byte ledp,int t ,byte l)
{
 x=pb;
 y=ledp;
 z=t;
 h=l;

  }  
 